import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
import pickle
import time
from category_encoders import TargetEncoder
import logging
from typing import Tuple, List, Dict, Any, Optional
import os
from joblib import Parallel, delayed
import warnings

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('xgboost_training.log'),
        logging.StreamHandler()
    ]
)

def train_xgboost_models(
    train_file_path: str,
    test_file_path: str,
    prediction_output_path: str,
    model_save_path: str = 'xgboost_models.pkl',
    n_splits: int = 5,          # 减少折数以提升速度
    n_jobs: int = -1,            # 并行处理
    num_boost_round: int = 1000,
    learning_rate: float = 0.05,
    early_stopping_rounds: int = 50,
    use_gpu: bool = False        # 是否使用GPU加速
):
    """
    训练 XGBoost 模型，使用 K-Fold 交叉验证，并在测试集上进行预测。
    预测结果保存到指定路径，同时保存训练好的模型和预处理器。

    参数:
    - train_file_path (str): 训练集 CSV 文件路径。
    - test_file_path (str): 测试集 CSV 文件路径。
    - prediction_output_path (str): 预测结果保存的 CSV 文件路径。
    - model_save_path (str): 训练好的模型和预处理器保存的文件路径。
    - n_splits (int): K-Fold 的折数。
    - n_jobs (int): 并行处理的作业数，-1 表示使用所有可用的CPU核心。
    - num_boost_round (int): XGBoost 的最大提升轮数。
    - learning_rate (float): XGBoost 的学习率。
    - early_stopping_rounds (int): 早停轮数。
    - use_gpu (bool): 是否使用GPU加速。
    """

    def load_and_preprocess_data(file_path: str) -> Tuple[pd.DataFrame, Optional[pd.Series]]:
        """
        加载并进行初步预处理的数据。

        Args:
            file_path (str): Path to the CSV file

        Returns:
            Tuple[pd.DataFrame, Optional[pd.Series]]: Features (X) and target (y) if available
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"数据文件未找到: {file_path}")

        try:
            data = pd.read_csv(file_path)
            logging.info(f"成功加载数据文件: {file_path}. 数据形状: {data.shape}")
        except Exception as e:
            logging.error(f"加载数据文件时出错: {file_path} 错误信息: {str(e)}")
            raise

        if 'Unnamed: 0' in data.columns:
            data = data.drop(columns='Unnamed: 0')

        X = data.drop('price', axis=1) if 'price' in data.columns else data
        y = data['price'] if 'price' in data.columns else None

        logging.info(f"特征列: {X.columns.tolist()}")
        if y is not None:
            logging.info(f"目标变量形状: {y.shape}")
            logging.info(f"价格范围: {y.min():.2f} 到 {y.max():.2f}")

        return X, y

    def preprocess_features(
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
        num_imputer: Optional[SimpleImputer] = None,
        cat_imputer: Optional[SimpleImputer] = None,
        target_encoder: Optional[TargetEncoder] = None,
        target_encode_cols: List[str] = ['make', 'model'],
        encoding_smoothing: float = 1.0
    ) -> Tuple[pd.DataFrame, SimpleImputer, SimpleImputer, TargetEncoder]:
        """
        预处理特征，包括填补缺失值、编码。

        Args:
            X (pd.DataFrame): 特征数据
            y (Optional[pd.Series]): 目标变量
            num_imputer (Optional[SimpleImputer]): 数值特征填充器
            cat_imputer (Optional[SimpleImputer]): 分类特征填充器
            target_encoder (Optional[TargetEncoder]): 目标编码器
            target_encode_cols (List[str]): 需要目标编码的分类特征
            encoding_smoothing (float): 目标编码平滑参数

        Returns:
            Tuple[pd.DataFrame, SimpleImputer, SimpleImputer, TargetEncoder]: 预处理后的数据及预处理器
        """
        if not isinstance(X, pd.DataFrame):
            raise TypeError("X 必须是 pandas DataFrame")

        X = X.copy()
        logging.info("开始特征预处理")

        # 确定特征类型
        numeric_features = X.select_dtypes(include=['int64', 'float64']).columns
        categorical_features = X.select_dtypes(include=['object']).columns

        logging.info(f"数值特征: {numeric_features.tolist()}")
        logging.info(f"分类特征: {categorical_features.tolist()}")

        # 处理数值特征缺失值
        if len(numeric_features) > 0:
            if num_imputer is None:
                num_imputer = SimpleImputer(strategy='median')
                X[numeric_features] = pd.DataFrame(
                    num_imputer.fit_transform(X[numeric_features]),
                    columns=numeric_features,
                    index=X.index
                )
                logging.info("数值特征缺失值已使用中位数填充")
            else:
                X[numeric_features] = pd.DataFrame(
                    num_imputer.transform(X[numeric_features]),
                    columns=numeric_features,
                    index=X.index
                )
                logging.info("使用现有的数值特征填充器填充数值特征缺失值")

        # 处理分类特征缺失值和编码
        if len(categorical_features) > 0:
            if cat_imputer is None:
                cat_imputer = SimpleImputer(strategy='constant', fill_value='unknown')
                X[categorical_features] = pd.DataFrame(
                    cat_imputer.fit_transform(X[categorical_features]),
                    columns=categorical_features,
                    index=X.index
                )
                logging.info("分类特征缺失值已填充为 'unknown'")
            else:
                X[categorical_features] = pd.DataFrame(
                    cat_imputer.transform(X[categorical_features]),
                    columns=categorical_features,
                    index=X.index
                )
                logging.info("使用现有的分类特征填充器填充分类特征缺失值")

            # 目标编码
            target_encode_features = [col for col in target_encode_cols if col in categorical_features]
            if target_encode_features and y is not None:
                if target_encoder is None:
                    target_encoder = TargetEncoder(cols=target_encode_features, smoothing=encoding_smoothing)
                    X[target_encode_features] = pd.DataFrame(
                        target_encoder.fit_transform(X[target_encode_features], y),
                        columns=target_encode_features,
                        index=X.index
                    )
                    logging.info(f"分类特征 {target_encode_features} 已进行目标编码")
                else:
                    X[target_encode_features] = pd.DataFrame(
                        target_encoder.transform(X[target_encode_features]),
                        columns=target_encode_features,
                        index=X.index
                    )
                    logging.info(f"使用现有的目标编码器对分类特征 {target_encode_features} 进行编码")

            # 其他分类特征进行独热编码（针对低基数特征）
            other_categorical = [col for col in categorical_features if col not in target_encode_features]
            if len(other_categorical) > 0:
                # 仅对基数较低的特征进行独热编码，以减少特征维度
                # 可以根据每个类别特征的唯一值数量进行筛选
                low_cardinality_cols = [col for col in other_categorical if X[col].nunique() < 10]
                high_cardinality_cols = [col for col in other_categorical if X[col].nunique() >= 10]

                if low_cardinality_cols:
                    encoder = OneHotEncoder(sparse=False, handle_unknown='ignore')
                    encoded_features = encoder.fit_transform(X[low_cardinality_cols])
                    encoded_feature_names = encoder.get_feature_names_out(low_cardinality_cols)
                    encoded_df = pd.DataFrame(encoded_features, columns=encoded_feature_names, index=X.index)
                    X = pd.concat([X, encoded_df], axis=1)
                    X = X.drop(columns=low_cardinality_cols)
                    logging.info(f"低基数分类特征 {low_cardinality_cols} 已进行独热编码")

                if high_cardinality_cols:
                    logging.info(f"高基数分类特征 {high_cardinality_cols} 将传递给 XGBoost 进行处理")
                    # 确保这些特征为字符串类型
                    for col in high_cardinality_cols:
                        X[col] = X[col].astype(str)

        logging.info(f"完成特征预处理。最终数据形状: {X.shape}")
        return X, num_imputer, cat_imputer, target_encoder

    def train_evaluate_xgboost(
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        params: Dict[str, Any],
        num_boost_round: int = 1000,
        early_stopping_rounds: int = 50
    ) -> xgb.Booster:
        """
        训练 XGBoost 模型并评估验证集性能。

        Args:
            X_train (pd.DataFrame): 训练特征
            y_train (pd.Series): 训练目标
            X_val (pd.DataFrame): 验证特征
            y_val (pd.Series): 验证目标
            params (Dict[str, Any]): XGBoost 参数
            num_boost_round (int): 最大提升轮数
            early_stopping_rounds (int): 早停轮数

        Returns:
            xgb.Booster: 训练好的模型
        """
        # 转换标签为对数空间
        y_train_log = np.log1p(y_train)
        y_val_log = np.log1p(y_val)

        # 创建 DMatrix
        dtrain = xgb.DMatrix(X_train, label=y_train_log)
        dval = xgb.DMatrix(X_val, label=y_val_log)

        evallist = [(dtrain, 'train'), (dval, 'eval')]

        # 训练模型
        model = xgb.train(
            params,
            dtrain,
            num_boost_round=num_boost_round,
            evals=evallist,
            early_stopping_rounds=early_stopping_rounds,
            verbose_eval=False  # 关闭训练日志输出
        )

        return model

    def post_process_predictions(
        predictions: np.ndarray,
        min_price: float = 700,
        max_price: float = 2900000
    ) -> np.ndarray:
        """
        后处理预测结果，限制价格范围。

        Args:
            predictions (np.ndarray): 预测结果
            min_price (float): 最小价格
            max_price (float): 最大价格

        Returns:
            np.ndarray: 后处理后的预测结果
        """
        return np.clip(predictions, min_price, max_price)

    def verify_saved_model(model_path: str) -> bool:
        """
        验证保存的模型的完整性和正确性。

        Args:
            model_path (str): 模型保存路径

        Returns:
            bool: 是否验证成功
        """
        try:
            with open(model_path, 'rb') as f:
                loaded_model = pickle.load(f)

            required_keys = ['models', 'feature_importance']
            missing_keys = [key for key in required_keys if key not in loaded_model]

            if missing_keys:
                raise ValueError(f"保存的模型缺少必要的键: {missing_keys}")

            logging.info("模型验证成功")
            return True
        except Exception as e:
            logging.error(f"模型验证失败: {str(e)}")
            return False

    def train_fold(
        fold: int,
        train_index: np.ndarray,
        val_index: np.ndarray,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        params: Dict[str, Any],
        num_boost_round: int,
        early_stopping_rounds: int
    ) -> Tuple[int, Dict[str, Any], np.ndarray, np.ndarray, pd.DataFrame]:
        """
        训练单个折，并返回相关信息。

        Args:
            fold (int): 折数
            train_index (np.ndarray): 训练索引
            val_index (np.ndarray): 验证索引
            X_train (pd.DataFrame): 全部训练特征
            y_train (pd.Series): 全部训练目标
            params (Dict[str, Any]): XGBoost 参数
            num_boost_round (int): 最大提升轮数
            early_stopping_rounds (int): 早停轮数

        Returns:
            Tuple[int, Dict[str, Any], np.ndarray, np.ndarray, pd.DataFrame]: 折数，模型字典，验证索引，预测结果，特征重要性
        """
        logging.info(f"\n开始训练第 {fold} 折模型")

        X_tr, X_val = X_train.iloc[train_index].copy(), X_train.iloc[val_index].copy()
        y_tr, y_val = y_train.iloc[train_index], y_train.iloc[val_index]

        # 预处理
        X_tr_processed, num_imputer, cat_imputer, target_encoder = preprocess_features(X_tr, y_tr)
        X_val_processed, _, _, _ = preprocess_features(
            X_val,
            y_val,
            num_imputer=num_imputer,
            cat_imputer=cat_imputer,
            target_encoder=target_encoder
        )

        # 训练模型
        model = train_evaluate_xgboost(
            X_tr_processed,
            y_tr,
            X_val_processed,
            y_val,
            params,
            num_boost_round=num_boost_round,
            early_stopping_rounds=early_stopping_rounds
        )

        # 预测验证集
        dval = xgb.DMatrix(X_val_processed)
        fold_predictions = np.expm1(model.predict(dval))

        # 收集特征重要性
        importance = model.get_score(importance_type='gain')
        feature_importance = pd.DataFrame({
            'feature': list(importance.keys()),
            'importance': list(importance.values())
        })

        # 保存模型和预处理器
        model_dict = {
            'model': model,
            'preprocessors': {
                'num_imputer': num_imputer,
                'cat_imputer': cat_imputer,
                'target_encoder': target_encoder
            }
        }

        return fold, model_dict, val_index, fold_predictions, feature_importance

    # 开始主逻辑
    try:
        np.random.seed(42)
        warnings.filterwarnings('ignore', category=UserWarning)

        logging.info("开始加载训练数据...")
        X_train, y_train = load_and_preprocess_data(train_file_path)

        logging.info("\n目标变量 (price) 统计信息:")
        logging.info(y_train.describe())

        # 初始化 K-Fold
        kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

        oof_predictions = np.zeros(len(X_train))
        feature_importance_list = []
        models = []

        # XGBoost 参数
        xgb_params = {
            'objective': 'reg:squarederror',
            'eval_metric': 'rmse',
            'booster': 'gbtree',
            'eta': learning_rate,
            'max_depth': 6,
            'min_child_weight': 1,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'gamma': 0,
            'reg_alpha': 0,    # L1正则化
            'reg_lambda': 1,    # L2正则化
            'seed': 42,
            'verbosity': 0      # 关闭XGBoost日志
        }

        # 如果使用GPU，调整参数
        if use_gpu:
            xgb_params['tree_method'] = 'gpu_hist'
            logging.info("启用GPU加速进行训练")
        else:
            xgb_params['tree_method'] = 'hist'
            logging.info("使用CPU进行训练")

        start_time = time.time()

        # 并行训练 K-Fold
        results = Parallel(n_jobs=n_jobs)(
            delayed(train_fold)(
                fold=fold,
                train_index=train_index,
                val_index=val_index,
                X_train=X_train,
                y_train=y_train,
                params=xgb_params,
                num_boost_round=num_boost_round,
                early_stopping_rounds=early_stopping_rounds
            )
            for fold, (train_index, val_index) in enumerate(kf.split(X_train), 1)
        )

        for result in results:
            fold, model_dict, val_index, fold_predictions, feature_importance = result
            logging.info(f"第 {fold} 折训练完成")

            # 赋值到 oof_predictions
            oof_predictions[val_index] = fold_predictions

            feature_importance_list.append(feature_importance)
            models.append(model_dict)

        elapsed_time = time.time() - start_time
        logging.info(f"\n总训练时间: {elapsed_time / 60:.2f} 分钟")

        # 评估 OOF 预测
        oof_predictions = post_process_predictions(oof_predictions)
        oof_mse = mean_squared_error(y_train, oof_predictions)
        oof_r2 = r2_score(y_train, oof_predictions)
        logging.info(f"Out-of-fold RMSE: {np.sqrt(oof_mse):.4f}")
        logging.info(f"Out-of-fold R2: {oof_r2:.4f}")

        # 特征重要性分析
        feature_importance = pd.concat(feature_importance_list).groupby('feature').mean()
        feature_importance = feature_importance.sort_values('importance', ascending=False)
        logging.info("\nTop 10 重要特征:")
        logging.info(feature_importance.head(10))

        # 保存模型和预处理器
        with open(model_save_path, 'wb') as f:
            pickle.dump({
                'models': models,
                'feature_importance': feature_importance
            }, f)
        logging.info(f"模型和预处理器已保存到 '{model_save_path}'")

        # 验证保存的模型
        if not verify_saved_model(model_save_path):
            raise RuntimeError("模型验证失败，保存的模型不完整或损坏")

        # 加载测试数据
        logging.info("开始加载测试数据...")
        X_test, _ = load_and_preprocess_data(test_file_path)

        final_predictions = np.zeros(len(X_test))

        # 对每个模型进行预测并取平均
        for i, model_dict in enumerate(models, 1):
            logging.info(f"使用模型 {i} 进行预测")
            model = model_dict['model']
            preprocessors = model_dict['preprocessors']

            # 预处理测试数据
            X_test_processed, _, _, _ = preprocess_features(
                X_test,
                y=None,
                num_imputer=preprocessors['num_imputer'],
                cat_imputer=preprocessors['cat_imputer'],
                target_encoder=preprocessors['target_encoder']
            )

            dtest = xgb.DMatrix(X_test_processed)
            preds = np.expm1(model.predict(dtest))
            final_predictions += preds

        # 取平均
        final_predictions /= len(models)

        # 后处理预测值
        final_predictions = post_process_predictions(final_predictions)

        # 保存预测结果
        submission = pd.DataFrame({
            'Id': range(len(final_predictions)),
            'Predicted': np.round(final_predictions).astype(int)
        })

        submission.to_csv(prediction_output_path, index=False)
        logging.info(f"预测完成。提交文件已保存为 '{prediction_output_path}'")

        # 输出预测统计信息
        logging.info("\n预测统计信息:")
        logging.info(f"最小值: {final_predictions.min():.2f}")
        logging.info(f"最大值: {final_predictions.max():.2f}")
        logging.info(f"均值: {final_predictions.mean():.2f}")
        logging.info(f"中位数: {np.median(final_predictions):.2f}")

    except Exception as e:
        logging.error(f"训练和预测过程中出现错误: {str(e)}")
        raise


if __name__ == '__main__':
    # 示例用法
    train_file = 'preprocessing/2024-10-21-silan/train_cleaned.csv'
    test_file = 'preprocessing/2024-10-21-silan/test_cleaned.csv'
    prediction_file = 'submission_xgboost.csv'

    train_xgboost_models(train_file, test_file, prediction_file, use_gpu=True)
