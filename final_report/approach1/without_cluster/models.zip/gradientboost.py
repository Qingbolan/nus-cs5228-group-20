import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import pickle
import time
from category_encoders import TargetEncoder
import logging
import warnings
from typing import Tuple, List, Dict, Any, Optional
import os
from joblib import Parallel, delayed

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('model_training.log'),
        logging.StreamHandler()
    ]
)

def train_gradient_boosting_models(
    train_file_path: str,
    test_file_path: str,
    prediction_output_path: str,
    model_save_path: str = 'gradient_boosting_models.pkl',
    n_splits: int = 5,  # 减少折数
    n_jobs: int = -1      # 并行处理
):
    """
    训练 GradientBoostingRegressor 模型，使用 K-Fold 交叉验证，并在测试集上进行预测。
    预测结果保存到指定路径，同时保存训练好的模型和预处理器。

    参数:
    - train_file_path (str): 训练集 CSV 文件路径。
    - test_file_path (str): 测试集 CSV 文件路径。
    - prediction_output_path (str): 预测结果保存的 CSV 文件路径。
    - model_save_path (str): 训练好的模型和预处理器保存的文件路径。
    - n_splits (int): K-Fold 的折数。
    - n_jobs (int): 并行处理的作业数，-1 表示使用所有可用的CPU核心。
    """

    def load_and_preprocess_data(file_path: str) -> Tuple[pd.DataFrame, Optional[pd.Series]]:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"数据文件未找到: {file_path}")

        try:
            data = pd.read_csv(file_path)
            logging.info(f"成功加载数据文件: {file_path}. 数据形状: {data.shape}")
        except Exception as e:
            logging.error(f"加载数据文件时出错: {file_path} 错误信息: {str(e)}")
            raise

        if 'Unnamed: 0' in data.columns:
            data = data.drop(columns='Unnamed: 0')

        X = data.drop('price', axis=1) if 'price' in data.columns else data
        y = data['price'] if 'price' in data.columns else None

        logging.info(f"特征形状: {X.shape}")
        if y is not None:
            logging.info(f"目标变量形状: {y.shape}")
            logging.info(f"价格范围: {y.min():.2f} 到 {y.max():.2f}")

        return X, y

    def preprocess_features(
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
        num_imputer: Optional[SimpleImputer] = None,
        cat_imputer: Optional[SimpleImputer] = None,
        target_encoder: Optional[TargetEncoder] = None,
        scaler: Optional[StandardScaler] = None,
        target_encode_cols: List[str] = ['make', 'model'],
        encoding_smoothing: float = 1.0
    ) -> Tuple[pd.DataFrame, SimpleImputer, SimpleImputer, TargetEncoder, StandardScaler]:
        if not isinstance(X, pd.DataFrame):
            raise TypeError("X 必须是 pandas DataFrame")

        X = X.copy()
        logging.info("开始特征预处理")

        # Identify feature types
        numeric_features = X.select_dtypes(include=['int64', 'float64']).columns
        categorical_features = X.select_dtypes(include=['object']).columns

        logging.info(f"数值特征: {numeric_features.tolist()}")
        logging.info(f"分类特征: {categorical_features.tolist()}")

        # Standard columns to scale
        columns_to_standardize = ['curb_weight', 'power', 'engine_cap', 'depreciation']
        columns_to_standardize = [col for col in columns_to_standardize if col in numeric_features]

        # Handle numeric features
        if len(numeric_features) > 0:
            if num_imputer is None:
                num_imputer = SimpleImputer(strategy='median')
                X[numeric_features] = pd.DataFrame(
                    num_imputer.fit_transform(X[numeric_features]),
                    columns=numeric_features,
                    index=X.index
                )
                logging.info("数值特征缺失值已使用中位数填充")
            else:
                X[numeric_features] = pd.DataFrame(
                    num_imputer.transform(X[numeric_features]),
                    columns=numeric_features,
                    index=X.index
                )
                logging.info("使用现有的数值特征填充器填充数值特征缺失值")

        # Scale selected features
        if columns_to_standardize:
            if scaler is None:
                scaler = StandardScaler()
                X[columns_to_standardize] = pd.DataFrame(
                    scaler.fit_transform(X[columns_to_standardize]),
                    columns=columns_to_standardize,
                    index=X.index
                )
                logging.info(f"数值特征 {columns_to_standardize} 已标准化")
            else:
                X[columns_to_standardize] = pd.DataFrame(
                    scaler.transform(X[columns_to_standardize]),
                    columns=columns_to_standardize,
                    index=X.index
                )
                logging.info(f"使用现有的标准化器标准化数值特征 {columns_to_standardize}")

        # Handle categorical features
        if len(categorical_features) > 0:
            if cat_imputer is None:
                cat_imputer = SimpleImputer(strategy='constant', fill_value='unknown')
                X[categorical_features] = pd.DataFrame(
                    cat_imputer.fit_transform(X[categorical_features]),
                    columns=categorical_features,
                    index=X.index
                )
                logging.info("分类特征缺失值已填充为 'unknown'")
            else:
                X[categorical_features] = pd.DataFrame(
                    cat_imputer.transform(X[categorical_features]),
                    columns=categorical_features,
                    index=X.index
                )
                logging.info("使用现有的分类特征填充器填充分类特征缺失值")

            # Target encoding
            target_encode_features = [col for col in target_encode_cols if col in categorical_features]
            if target_encode_features and y is not None:
                if target_encoder is None:
                    target_encoder = TargetEncoder(cols=target_encode_features, smoothing=encoding_smoothing)
                    X[target_encode_features] = pd.DataFrame(
                        target_encoder.fit_transform(X[target_encode_features], y),
                        columns=target_encode_features,
                        index=X.index
                    )
                    logging.info(f"分类特征 {target_encode_features} 已进行目标编码")
                else:
                    X[target_encode_features] = pd.DataFrame(
                        target_encoder.transform(X[target_encode_features]),
                        columns=target_encode_features,
                        index=X.index
                    )
                    logging.info(f"使用现有的目标编码器对分类特征 {target_encode_features} 进行编码")

            # One-hot encoding for remaining categorical features
            other_categorical = [col for col in categorical_features if col not in target_encode_features]
            if len(other_categorical) > 0:
                encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
                encoded_features = encoder.fit_transform(X[other_categorical])
                encoded_feature_names = encoder.get_feature_names_out(other_categorical)
                encoded_df = pd.DataFrame(encoded_features, columns=encoded_feature_names, index=X.index)
                X = pd.concat([X, encoded_df], axis=1)
                X = X.drop(columns=other_categorical)
                logging.info(f"其他分类特征 {other_categorical} 已进行独热编码")

        logging.info(f"完成特征预处理。最终数据形状: {X.shape}")
        return X, num_imputer, cat_imputer, target_encoder, scaler

    def train_gradientBoosting(
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        params: Dict[str, Any]
    ) -> GradientBoostingRegressor:
        """
        Train a GradientBoostingRegressor model.
        """
        model = GradientBoostingRegressor(**params)
        model.fit(X_train, y_train)

        # Calculate validation metrics
        val_predictions = model.predict(X_val)
        val_mse = mean_squared_error(y_val, val_predictions)
        val_r2 = r2_score(y_val, val_predictions)

        logging.info(f"验证集 RMSE: {np.sqrt(val_mse):.4f}")
        logging.info(f"验证集 R2: {val_r2:.4f}")

        return model

    def post_process_predictions(
        predictions: np.ndarray,
        min_price: float = 700,
        max_price: float = 2900000
    ) -> np.ndarray:
        """
        Post-process predictions by clipping to valid range.
        """
        return np.clip(predictions, min_price, max_price)

    def verify_saved_model(model_path: str) -> bool:
        """
        Verify the completeness and integrity of a saved model.
        """
        try:
            with open(model_path, 'rb') as f:
                loaded_model = pickle.load(f)

            required_keys = ['models', 'feature_importance']
            missing_keys = [key for key in required_keys if key not in loaded_model]

            if missing_keys:
                raise ValueError(f"Saved model missing required keys: {missing_keys}")

            logging.info("模型验证成功")
            return True
        except Exception as e:
            logging.error(f"模型验证失败: {str(e)}")
            return False

    def train_fold(
        fold: int,
        train_index: np.ndarray,
        val_index: np.ndarray,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        gb_params: Dict[str, Any]
    ) -> Tuple[int, Dict[str, Any], np.ndarray, pd.DataFrame, np.ndarray]:
        """
        Function to train a single fold.
        Returns fold number, model dictionary, validation indices, fold predictions, and feature importance.
        """
        logging.info(f"\n开始训练第 {fold} 折模型")

        X_tr, X_val = X_train.iloc[train_index].copy(), X_train.iloc[val_index].copy()
        y_tr, y_val = y_train.iloc[train_index], y_train.iloc[val_index]

        # 预处理
        X_tr_processed, num_imputer, cat_imputer, target_encoder, scaler = preprocess_features(X_tr, y_tr)
        X_val_processed, _, _, _, _ = preprocess_features(
            X_val,
            y_val,
            num_imputer=num_imputer,
            cat_imputer=cat_imputer,
            target_encoder=target_encoder,
            scaler=scaler
        )

        # 训练模型
        model = train_gradientBoosting(
            X_tr_processed,
            y_tr,
            X_val_processed,
            y_val,
            gb_params
        )

        # 预测验证集
        fold_predictions = model.predict(X_val_processed)

        # 收集特征重要性
        importance = model.feature_importances_
        feature_importance = pd.DataFrame({
            'feature': X_tr_processed.columns,
            'importance': importance
        })

        # 保存模型和预处理器
        model_dict = {
            'model': model,
            'preprocessors': {
                'num_imputer': num_imputer,
                'cat_imputer': cat_imputer,
                'target_encoder': target_encoder,
                'scaler': scaler
            }
        }

        return fold, model_dict, val_index, fold_predictions, feature_importance

    # 开始主逻辑
    try:
        np.random.seed(42)
        warnings.filterwarnings('ignore', category=UserWarning)

        # 加载训练数据
        X_train, y_train = load_and_preprocess_data(train_file_path)

        logging.info("\n目标变量 (price) 统计信息:")
        logging.info(y_train.describe())

        # 初始化 K-Fold
        kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

        oof_predictions = np.zeros(len(X_train))
        feature_importance_list = []
        models = []

        # Gradient Boosting 参数
        gb_params = {
            'n_estimators': 1000,          # 减少 n_estimators
            'learning_rate': 0.1,          # 增加 learning_rate
            'max_depth': 5,
            'min_samples_split': 20,
            'min_samples_leaf': 15,
            'loss': 'huber',
            'random_state': 42
        }

        start_time = time.time()

        # 并行训练 K-Fold
        results = Parallel(n_jobs=n_jobs)(
            delayed(train_fold)(fold, train_index, val_index, X_train, y_train, gb_params)
            for fold, (train_index, val_index) in enumerate(kf.split(X_train), 1)
        )

        for result in results:
            fold, model_dict, val_index, fold_predictions, feature_importance = result
            logging.info(f"第 {fold} 折训练完成")

            # 赋值到 oof_predictions
            oof_predictions[val_index] = fold_predictions

            feature_importance_list.append(feature_importance)
            models.append(model_dict)

        # 训练完成统计
        elapsed_time = time.time() - start_time
        logging.info(f"\n总训练时间: {elapsed_time/60:.2f} 分钟")

        # 评估 OOF 预测
        oof_predictions = post_process_predictions(oof_predictions)
        oof_mse = mean_squared_error(y_train, oof_predictions)
        oof_r2 = r2_score(y_train, oof_predictions)
        logging.info(f"Out-of-fold RMSE: {np.sqrt(oof_mse):.4f}")
        logging.info(f"Out-of-fold R2: {oof_r2:.4f}")

        # 特征重要性分析
        feature_importance = pd.concat(feature_importance_list).groupby('feature').mean()
        feature_importance = feature_importance.sort_values('importance', ascending=False)
        logging.info("\nTop 10 重要特征:")
        logging.info(feature_importance.head(10))

        # 保存模型和预处理器
        with open(model_save_path, 'wb') as f:
            pickle.dump({
                'models': models,
                'feature_importance': feature_importance
            }, f)
        logging.info(f"模型和预处理器已保存到 '{model_save_path}'")

        # 验证保存的模型
        if not verify_saved_model(model_save_path):
            raise RuntimeError("模型验证失败，保存的模型不完整或损坏")

        # 加载测试数据
        X_test, _ = load_and_preprocess_data(test_file_path)

        final_predictions = np.zeros(len(X_test))

        # 对每个模型进行预测并取平均
        for i, model_dict in enumerate(models, 1):
            logging.info(f"使用模型 {i} 进行预测")
            model = model_dict['model']
            preprocessors = model_dict['preprocessors']

            # 预处理测试数据
            X_test_processed, _, _, _, _ = preprocess_features(
                X_test,
                y=None,
                num_imputer=preprocessors['num_imputer'],
                cat_imputer=preprocessors['cat_imputer'],
                target_encoder=preprocessors['target_encoder'],
                scaler=preprocessors['scaler']
            )

            preds = model.predict(X_test_processed)
            final_predictions += preds

        # 取平均
        final_predictions /= len(models)

        # 后处理预测值
        final_predictions = post_process_predictions(final_predictions)

        # 保存预测结果
        submission = pd.DataFrame({
            'Id': range(len(final_predictions)),
            'Predicted': np.round(final_predictions).astype(int)
        })

        submission.to_csv(prediction_output_path, index=False)
        logging.info(f"预测完成。提交文件已保存为 '{prediction_output_path}'")

        # 输出预测统计信息
        logging.info("\n预测统计信息:")
        logging.info(f"最小值: {final_predictions.min():.2f}")
        logging.info(f"最大值: {final_predictions.max():.2f}")
        logging.info(f"均值: {final_predictions.mean():.2f}")
        logging.info(f"中位数: {np.median(final_predictions):.2f}")

    except Exception as e:
        logging.error(f"发生错误: {str(e)}")
        raise

# 示例用法（取消注释后使用）
# if __name__ == '__main__':
#     train_file = 'preprocessing/2024-10-21-silan/train_cleaned.csv'
#     test_file = 'preprocessing/2024-10-21-silan/test_cleaned.csv'
#     prediction_file = '10-27-release_gradientBoosting.csv'

#     train_gradient_boosting_models(train_file, test_file, prediction_file)
