import pandas as pd
import numpy as np
from catboost import CatBoostRegressor
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
import pickle
import time
from typing import Tuple, List, Dict, Any, Optional
import os
import logging
import warnings
from joblib import Parallel, delayed

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('model_training.log'),
        logging.StreamHandler()
    ]
)

def train_catboost_models(
    train_file_path: str,
    test_file_path: str,
    prediction_output_path: str,
    model_save_path: str = 'catboost_models.pkl',
    n_splits: int = 5,         # 减少折数
    n_jobs: int = -1,           # 并行处理
    cb_params: Dict[str, Any] = None  # CatBoost 参数
):
    """
    训练 CatBoostRegressor 模型，使用 K-Fold 交叉验证，并在测试集上进行预测。
    预测结果保存到指定路径，同时保存训练好的模型和预处理器。

    参数:
    - train_file_path (str): 训练集 CSV 文件路径。
    - test_file_path (str): 测试集 CSV 文件路径。
    - prediction_output_path (str): 预测结果保存的 CSV 文件路径。
    - model_save_path (str): 训练好的模型和预处理器保存的文件路径。
    - n_splits (int): K-Fold 的折数。
    - n_jobs (int): 并行处理的作业数，-1 表示使用所有可用的CPU核心。
    - cb_params (Dict[str, Any]): CatBoost 的参数字典。
    """

    def load_and_preprocess_data(file_path: str) -> Tuple[pd.DataFrame, Optional[pd.Series]]:
        """加载并进行初步预处理的数据."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"数据文件未找到: {file_path}")

        try:
            data = pd.read_csv(file_path)
            logging.info(f"成功加载数据文件: {file_path}. 数据形状: {data.shape}")
        except Exception as e:
            logging.error(f"加载数据文件时出错: {file_path} 错误信息: {str(e)}")
            raise

        if 'Unnamed: 0' in data.columns:
            data = data.drop(columns='Unnamed: 0')

        X = data.drop('price', axis=1) if 'price' in data.columns else data
        y = data['price'] if 'price' in data.columns else None

        logging.info(f"特征形状: {X.shape}")
        if y is not None:
            logging.info(f"目标变量形状: {y.shape}")
            logging.info(f"价格范围: {y.min():.2f} 到 {y.max():.2f}")

        return X, y

    def preprocess_features(
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
        num_imputer: Optional[SimpleImputer] = None,
        scaler: Optional[StandardScaler] = None,
        categorical_features: Optional[List[str]] = None
    ) -> Tuple[pd.DataFrame, SimpleImputer, StandardScaler, List[str]]:
        """特征预处理，针对 CatBoost 优化."""
        if not isinstance(X, pd.DataFrame):
            raise TypeError("X 必须是 pandas DataFrame")

        X = X.copy()
        logging.info("开始特征预处理")

        if categorical_features is None:
            categorical_features = X.select_dtypes(include=['object']).columns.tolist()
        numeric_features = [col for col in X.columns if col not in categorical_features]

        logging.info(f"数值特征: {numeric_features}")
        logging.info(f"分类特征: {categorical_features}")

        # 处理数值特征缺失值
        if len(numeric_features) > 0:
            if num_imputer is None:
                num_imputer = SimpleImputer(strategy='median')
                X[numeric_features] = num_imputer.fit_transform(X[numeric_features])
                logging.info("数值特征缺失值已使用中位数填充")
            else:
                X[numeric_features] = num_imputer.transform(X[numeric_features])
                logging.info("使用现有的数值特征填充器填充数值特征缺失值")

        # 标准化特定的数值特征
        # 这里建议尝试不进行标准化，看看是否对模型性能有提升
        columns_to_standardize = ['curb_weight', 'power', 'engine_cap', 'depreciation']
        columns_to_standardize = [col for col in columns_to_standardize if col in numeric_features]

        if columns_to_standardize:
            if scaler is None:
                scaler = StandardScaler()
                X[columns_to_standardize] = scaler.fit_transform(X[columns_to_standardize])
                logging.info(f"数值特征 {columns_to_standardize} 已标准化")
            else:
                X[columns_to_standardize] = scaler.transform(X[columns_to_standardize])
                logging.info(f"使用现有的标准化器标准化数值特征 {columns_to_standardize}")

        # 处理分类特征缺失值和类型
        for cat_feature in categorical_features:
            if cat_feature in X.columns:
                X[cat_feature] = X[cat_feature].fillna('unknown')
                X[cat_feature] = X[cat_feature].astype(str)
                logging.info(f"分类特征 {cat_feature} 缺失值已填充为 'unknown'")

        logging.info(f"完成特征预处理。最终数据形状: {X.shape}")
        return X, num_imputer, scaler, categorical_features

    def train_catboost(
        fold: int,
        train_index: np.ndarray,
        val_index: np.ndarray,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        cb_params: Dict[str, Any],
        categorical_features: List[str]
    ) -> Tuple[int, Dict[str, Any], np.ndarray, np.ndarray, pd.DataFrame]:
        """训练单个折的 CatBoost 模型."""
        logging.info(f"\n开始训练第 {fold} 折模型")

        X_tr, X_val = X_train.iloc[train_index].copy(), X_train.iloc[val_index].copy()
        y_tr, y_val = y_train.iloc[train_index], y_train.iloc[val_index]

        # 预处理
        X_tr_processed, num_imputer, scaler, categorical_features = preprocess_features(X_tr, y_tr)
        X_val_processed, _, _, _ = preprocess_features(
            X_val,
            y_val,
            num_imputer=num_imputer,
            scaler=scaler,
            categorical_features=categorical_features
        )

        # 训练模型
        model = CatBoostRegressor(**cb_params)
        model.fit(
            X_tr_processed, y_tr,
            eval_set=(X_val_processed, y_val),
            cat_features=categorical_features,
            use_best_model=True,
            verbose=False,
            early_stopping_rounds=100  # 启用早停
        )

        # 预测验证集
        fold_predictions = model.predict(X_val_processed)

        # 收集特征重要性
        importance = model.get_feature_importance()
        feature_importance = pd.DataFrame({
            'feature': X_tr_processed.columns,
            'importance': importance
        })

        # 保存模型和预处理器
        model_dict = {
            'model': model,
            'preprocessors': {  # 修改点：将预处理器封装到 'preprocessors' 字典中
                'num_imputer': num_imputer,
                'scaler': scaler
            },
            'categorical_features': categorical_features
        }

        logging.info(f"第 {fold} 折模型训练完成")

        return fold, model_dict, val_index, fold_predictions, feature_importance

    def post_process_predictions(predictions: np.ndarray, min_price: float = 700,
                                 max_price: float = 2900000) -> np.ndarray:
        """后处理预测结果，限制价格范围."""
        return np.clip(predictions, min_price, max_price)

    def verify_saved_model(model_path: str) -> bool:
        """验证保存的模型的完整性."""
        try:
            with open(model_path, 'rb') as f:
                loaded_model = pickle.load(f)

            required_keys = ['models', 'feature_importance']
            missing_keys = [key for key in required_keys if key not in loaded_model]

            if missing_keys:
                raise ValueError(f"Saved model missing required keys: {missing_keys}")

            logging.info("模型验证成功")
            return True
        except Exception as e:
            logging.error(f"模型验证失败: {str(e)}")
            return False

    # 开始主逻辑
    try:
        np.random.seed(42)
        warnings.filterwarnings('ignore', category=UserWarning)

        # 加载训练数据
        X_train, y_train = load_and_preprocess_data(train_file_path)

        logging.info("\n目标变量 (price) 统计信息:")
        logging.info(y_train.describe())

        # 初始化 K-Fold
        kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

        oof_predictions = np.zeros(len(X_train))
        feature_importance_list = []
        models = []

        # CatBoost 参数
        if cb_params is None:
            cb_params = {
                # 'n_estimators': 1000,          # 减少 n_estimators
                # 'learning_rate': 0.1,          # 增加 learning_rate
                # 'max_depth': 5,
                # 'min_samples_split': 20,
                # 'min_samples_leaf': 15,
                # 'loss': 'huber',
                # 'random_state': 42
                'iterations': 5000,               # 从3000减少到1000
                'learning_rate': 0.1,              # 增加学习率
                'depth': 6,
                'l2_leaf_reg': 10,
                'min_data_in_leaf': 20,
                'random_strength': 0.5,
                'bagging_temperature': 0.2,
                'od_type': 'Iter',
                'od_wait': 100,                    # 增加 od_wait 以配合早停
                'random_seed': 42,
                'verbose': False,
                'task_type': 'CPU',                # 如果有GPU，可以改为 'GPU'
                'allow_writing_files': False       # 禁止CatBoost写入文件以加快速度
            }

        start_time = time.time()

        # 并行训练 K-Fold
        results = Parallel(n_jobs=n_jobs)(
            delayed(train_catboost)(
                fold=fold,
                train_index=train_index,
                val_index=val_index,
                X_train=X_train,
                y_train=y_train,
                cb_params=cb_params,
                categorical_features=X_train.select_dtypes(include=['object']).columns.tolist()
            )
            for fold, (train_index, val_index) in enumerate(kf.split(X_train), 1)
        )

        for result in results:
            fold, model_dict, val_index, fold_predictions, feature_importance = result
            logging.info(f"第 {fold} 折训练完成")

            # 赋值到 oof_predictions
            oof_predictions[val_index] = fold_predictions

            feature_importance_list.append(feature_importance)
            models.append(model_dict)

        # 训练完成统计
        elapsed_time = time.time() - start_time
        logging.info(f"\n总训练时间: {elapsed_time / 60:.2f} 分钟")

        # 评估 OOF 预测
        oof_predictions = post_process_predictions(oof_predictions)
        oof_mse = mean_squared_error(y_train, oof_predictions)
        oof_r2 = r2_score(y_train, oof_predictions)
        logging.info(f"Out-of-fold RMSE: {np.sqrt(oof_mse):.4f}")
        logging.info(f"Out-of-fold R2: {oof_r2:.4f}")

        # 特征重要性分析
        feature_importance = pd.concat(feature_importance_list).groupby('feature').mean()
        feature_importance = feature_importance.sort_values('importance', ascending=False)
        logging.info("\nTop 10 重要特征:")
        logging.info(feature_importance.head(10))

        # 保存模型
        with open(model_save_path, 'wb') as f:
            pickle.dump({
                'models': models,
                'feature_importance': feature_importance
            }, f)
        logging.info(f"模型和预处理器已保存到 '{model_save_path}'")

        # 验证保存的模型
        if not verify_saved_model(model_save_path):
            raise RuntimeError("模型验证失败，保存的模型不完整或损坏")

        # 加载测试数据
        X_test, _ = load_and_preprocess_data(test_file_path)

        final_predictions = np.zeros(len(X_test))

        # 对每个模型进行预测并取平均
        for i, model_dict in enumerate(models, 1):
            logging.info(f"使用模型 {i} 进行预测")
            model = model_dict['model']
            preprocessors = model_dict['preprocessors']
            num_imputer = preprocessors.get('num_imputer', None)
            scaler = preprocessors.get('scaler', None)
            categorical_features = model_dict['categorical_features']

            # 预处理测试数据
            X_test_processed, _, _, _ = preprocess_features(
                X_test,
                y=None,
                num_imputer=num_imputer,
                scaler=scaler,
                categorical_features=categorical_features
            )

            preds = model.predict(X_test_processed)
            final_predictions += preds

        # 取平均
        final_predictions /= len(models)

        # 后处理预测值
        final_predictions = post_process_predictions(final_predictions)

        # 保存预测结果
        submission = pd.DataFrame({
            'Id': range(len(final_predictions)),
            'Predicted': np.round(final_predictions).astype(int)
        })

        submission.to_csv(prediction_output_path, index=False)
        logging.info(f"预测完成。提交文件已保存为 '{prediction_output_path}'")

        # 输出预测统计信息
        logging.info("\n预测统计信息:")
        logging.info(f"最小值: {final_predictions.min():.2f}")
        logging.info(f"最大值: {final_predictions.max():.2f}")
        logging.info(f"均值: {final_predictions.mean():.2f}")
        logging.info(f"中位数: {np.median(final_predictions):.2f}")

    except Exception as e:
        logging.error(f"主执行过程中发生致命错误: {str(e)}")
        raise

if __name__ == '__main__':
    # 示例用法
    train_file = 'preprocessing/2024-10-21-silan/train_cleaned.csv'
    test_file = 'preprocessing/2024-10-21-silan/test_cleaned.csv'
    prediction_file = '10-27-release_catboost.csv'

    train_catboost_models(train_file, test_file, prediction_file)
